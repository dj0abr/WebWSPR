#include <gd.h>
void drawSpec(gdImagePtr dst, double *d, int fstart, int fend, int samplecnt);
void drawSpec_Init();
