void hamlib_maketable();
void hamlib_ptt(int onoff);
void hamlib_setQRG(double trx_frequency);

