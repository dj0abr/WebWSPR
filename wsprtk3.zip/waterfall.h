void makeWF(unsigned int *psamples, int anz, int samplecnt);
void restoreWF();

