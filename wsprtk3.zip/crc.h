unsigned int crc32_messagecalc(unsigned char *data, int len);
