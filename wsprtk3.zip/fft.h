void init_fft();
void exit_fft();
void doFFT(short *samples,int samplecnt, int chans);
