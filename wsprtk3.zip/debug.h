
void current_time(char *text);
void deb_printf(char const *src, char *fmt, ...);

extern int makeprot; 

