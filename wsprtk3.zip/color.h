#include <gd.h>
int getPixelColor(float val);
void allocatePalette(gdImagePtr img);
void calcColorParms(int fstart, int fend, double *d);
