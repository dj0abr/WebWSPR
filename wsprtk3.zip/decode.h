int decode_wspr_init();
char *getWAVfilename(char *path);
