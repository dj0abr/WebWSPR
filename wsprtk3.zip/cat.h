int cat_init();
int getCivFreq();
void write_port(unsigned char *data, int len);
void civ_queryQRG();

extern int ser_command;
extern char device[20];
