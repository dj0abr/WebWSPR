void wsprcoder();

extern short txsamples[WSPR_RATE*MAXSECONDS];
