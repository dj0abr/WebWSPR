int readCIVmessage(int reti);
void civ_ptt(int onoff, unsigned char civad);
void civ_setQRG(double freq);
void civ_queryQRG();

#define MAXCIVDATA 30
