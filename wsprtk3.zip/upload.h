int upload_init();
char *getDECfilename(char *path);
int getFileSize(char *fn);
